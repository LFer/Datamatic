#!/usr/bin/perl

# Modulos en uso
use warnings;
use strict;
use diagnostics;
use Text::ParseWords;

# Constantes
use constant {
   NOMBRE => 1,
   CODIGO => 0
};

# Variables locales
my $csvfile = "departamentos.txt";
my $xmlfile = "res_country_state.xml";
my $linea   = ();
my @campos  = ();

# Abrir Archivos
open( CSV, "<$csvfile" ) or die("Imposible abrir $csvfile: $!\\n");
open( XML, ">$xmlfile" ) or die("Imposible abrir $xmlfile: $!\\n");
select(XML);

# Encabezado
print qq{<?xml version="1.0" encoding="utf-8"?>\n};
print qq{<openerp>\n};
print qq{    <data noupdate="True">\n\n};

# Procesar cada linea de datos
while ( $linea = <CSV> ) {
 
   chomp $linea;
   @campos = &quotewords( ',', 0, $linea ) or ( warn "error en la linea $.:$_" );
   
   print qq{        <record model="res.country.state" id="$campos[CODIGO]">\n};
   print qq{            <field name="name">$campos[NOMBRE]</field>\n};
   print qq{            <field name="code">$campos[CODIGO]</field>\n};
   print qq{            <field name="country_id" ref="base.uy"/>\n};
   print qq{        </record>\n\n};

}

# Pie
print qq{    </data>\n};
print qq{</openerp>\n};

select STDOUT;
print "$xmlfile generado.\n";

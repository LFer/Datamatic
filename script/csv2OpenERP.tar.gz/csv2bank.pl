#!/usr/bin/perl

# Modulos en uso
use warnings;
use strict;
use diagnostics;
use Text::ParseWords;

# Constantes
use constant {
   NOMBRE  => 0,
   CODIGO  => 1,
   CALLE   => 2,
   CIUDAD  => 3,
   TEL     => 4,
   FAX     => 5
};

# Variables locales
my $csvfile = "bancos.txt";
my $xmlfile = "res_bank.xml";
my $linea   = ();
my @campos  = ();

# Abrir Archivos
open( CSV, "<$csvfile" ) or die("Imposible abrir $csvfile: $!\\n");
open( XML, ">$xmlfile" ) or die("Imposible abrir $xmlfile: $!\\n");
select(XML);

# Encabezado
print qq{<?xml version="1.0" encoding="utf-8"?>\n};
print qq{<openerp>\n};
print qq{    <data noupdate="True">\n\n};

# Procesar cada linea de datos
while ( $linea = <CSV> ) {
 
   chomp $linea;
   @campos = &quotewords( ',', 0, $linea ) or ( warn "error en la linea $.:$_" );
   
   print qq{        <record model="res.bank" id="$campos[CODIGO]">\n};
   print qq{            <field name="name">$campos[NOMBRE]</field>\n};
   print qq{            <field name="bic">$campos[CODIGO]</field>\n};
   print qq{            <field name='active'>1</field>\n};   
   print qq{            <field name="street">$campos[CALLE]</field>\n};
   print qq{            <field name="city">$campos[CIUDAD]</field>\n};
   print qq{            <field name='state' ref='l10n_uy_states.MO'/>\n};
   print qq{            <field name='country' ref='base.uy'/>\n};
   print qq{            <field name="phone">$campos[TEL]</field>\n};
   print qq{            <field name="fax">$campos[FAX]</field>\n};
   print qq{        </record>\n\n};

}

# Pie
print qq{    </data>\n};
print qq{</openerp>\n};

select STDOUT;
print "$xmlfile generado.\n";
